"use strict";

/*
create calendar for fall semester
*/


//setting display date
var thisDay = new Date("August 31, 2020");

document.getElementById("calendar").innerHTML = createCalendar(thisDay);

//to create calendar
function createCalendar(calDate) {
    var calendarHTML = "<table id='calendarTable'>";
    calendarHTML += calCaption(calDate);
    //calendarHTML += calWeekdayRow();
    //calendarHTML += calDays(calDate);
    calendarHTML += "</table>";
    return calendarHTML;
}

/*calendar caption*/
function calCaption(calDate) {
	// monthName arry contains the list of month names 
	var monthName = ["January", "February", "March", "April", "May", "June" , "July", "August", "September", "October", "November", "December"];

	//current month
	var thisMonth = calDate.getMonth();

	//current year
	var thisYear = calDate.getFullYear();

	//return caption 
	return "<caption>" + monthName[thisMonth] + " " + thisYear + "</caption>";
}


// table row with weekdays
function calWeekdayRow() {
    
    var dayName = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];
    var rowHTML = "<tr>";
    
    //loop Through the dayName array
    for (var i = 0; i < dayName.length; i++) {
        rowHTML += "<th class='calender_weekdays'>" + dayName[i] +"</th>";

    //add closing row tag
    rowHTML += "</tr>";
    return rowHTML;
}

//days in month
function daysInMonth(calDate) {
	var dayCount = [31,28,31,30,31,30,31,31,30,31,30,31];

	//get year and month
	var thisYear = calDate.getFullYear();
	var thisMonth = calDate.getMonth();

	//february mess
	if (thisYear % 4 === 0) {
	    dayCount[1] = 29;
	    if ((thisYear % 100 != 0) || (thisYear % 400 ===0)) {
	        dayCount[1] = 29;
	    }
	}

	//return days
	return dayCount[thisMonth];
}


//create rows for days
function calDays(calDate) {
    //first day of the month
    var day = new Date(calDate.getFullYear(), calDate.getMonth(), 1);
    var weekDay = day.getDay(); 
    //create blank days
    var htmlCode = "<tr>";
    for (var i = 0; i < weekDay; i++) {
        htmlCode += "<td></td>"
    }
    //depending on the month add days
    var totalDays = daysInMonth(calDate);
    var highlighDay = calDate.getDate();
    for (var i = 1; i <= totalDays; i++) {
        day.setDate(i);
        weekDay = day.getDay();

        if (weekDay === 0) htmlCode += "<tr>";
        if (i === highlighDay) {
            htmlCode += "<td class='calendar_dates' id='calendar_today'>" + i + dayEvent[i] +  "</td>";
        } else {
            htmlCode += "<td class='calendar_dates'>" + i + dayEvent[i] + "</td>";
        }
        if (weekDay === 6) htmlCode += "</tr>";
    }
    //return rows
    return htmlCode;
}