"use strict";

var dayEvent = new Array();

dayEvent[1] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";


dayEvent[2] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";
dayEvent[3] = "";
dayEvent[4] = "";
dayEvent[5] = "";
dayEvent[6] = "";
dayEvent[7] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";
dayEvent[8] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";


dayEvent[9] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";
dayEvent[10] = "";
dayEvent[11] = "";
dayEvent[12] = "";
dayEvent[13] = "";
dayEvent[14] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";
dayEvent[15] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";


dayEvent[16] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";
dayEvent[17] = "";
dayEvent[18] = "";
dayEvent[19] = "";
dayEvent[20] = "";
dayEvent[21] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";
dayEvent[22] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";


dayEvent[23] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";
dayEvent[24] = "";
dayEvent[25] = "";
dayEvent[26] = "<br> <b>ARTD 2811</b>  <br> (9:30 AM - 1:10 PM)   <br>  <b>CISC 1003</b> <br> (3:40 PM - 6:25 PM)  <br>  <b>CISC 3630</b> <br> (6:30 PM - 9:10 PM)";
dayEvent[27] = "<br> <b>CISC 2210</b> <br> (11:00 AM - 12:15 PM)  <br>  <b>MATH 1206</b>  <br> (1:25 PM - 3:30 PM)";
dayEvent[28] = "";
dayEvent[29] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";


dayEvent[30] = "<br> <b>Work</b> <br> (12:00 PM - 10:00 PM)";

